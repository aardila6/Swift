//: Playground - noun: a place where people can play
// Prueba para evaluacion alfonso ardila 2016
// Cambios para que funcione bien en github


import UIKit


var rango = 0...100


for num in rango{
    
    if (( num / 5 > 0 ) && ( num % 5 == 0) ) {
        print(" # \(num) \t Bingo !!! ")
    }
    if ((num / 2) > 0 && (num % 2 == 0)) {
        print( "# \(num)\t Par !!! ")
    } else if (( num == 1  || num % 2 != 0)) {
        print( "# \(num)\t Impar !!! ")
    }
    
    if ( num >= 30 ) && ( num <= 40 ) {
        print( "# \(num) \t Viva Swift !!!")
    }
}


