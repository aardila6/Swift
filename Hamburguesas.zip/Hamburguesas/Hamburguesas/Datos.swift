//
//  Datos.swift
//  Hamburguesas
//
//  Created by Alfonso Ardila Toro on 23/05/16.
//  Copyright © 2016 MultiPOS Soluciones. All rights reserved.
//

import Foundation
import UIKit

class ColeccionDePaises{
    
    let pais = ["Colombia","México","Panamá","Argentina","Venezuela","Ecuador","USA","Canadá",
                "Chile","Perú","Brasil","Uruguay","Bolivia","Paraguay","Portugal","España",
                "China","Francia","Alemania","Suiza"]
    
    func obtenPais( )->String {
        let posicion = Int (arc4random()) % pais.count
        return pais[posicion]
        
        
    }
    
}

class ColeccionDeHamburguesa{
    
    let hamburguesa = ["Colombiana U$ 4","Mexicana U$ 5","Panameña U$ 6 ","Gaucha U$ 3","Petrolera U$ 8","Ecuatoriana U$ 5","Americana U$ 5","Canadiense U$ 7",
                       "Chilena U$ 3","Peruana U$ 6","Carioca U$ 5","Uruguaya U$ 3","Boliviana U$ 4","Paraguaya U$ 2","Portuguesa Eur 4","Española Eur 6",
                       "China Us 1","Francesa Eur 5","Alemana Eur 8","Suiza Eur 10"]
    
    func obtenHamburguesa( )->String {
        let posicion = Int (arc4random()) % hamburguesa.count
        return hamburguesa[posicion]
    }
    
}