//
//  ViewController.swift
//  Hamburguesas
//
//  Created by Alfonso Ardila Toro on 23/05/16.
//  Copyright © 2016 MultiPOS Soluciones. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    // @IBoutlet para la etiqueta de país
    
    @IBOutlet weak var nombrePais: UILabel!

    // @IBoutlet para la etiqueta de Hamburguesas
    
    @IBOutlet weak var tipoHamburguesa: UILabel!

    let traeLosPaises = ColeccionDePaises()
    let traeLasHamburguesas = ColeccionDeHamburguesa()
    let colores = Colores()

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
        @IBAction func quieroUnaHamburguesa() {
      
        
        nombrePais.text = traeLosPaises.obtenPais()
        tipoHamburguesa.text = traeLasHamburguesas.obtenHamburguesa()
        let colorAleatorio = colores.regresaColorAleatorio()
        
    
        // Asigno Colores
        
        view.backgroundColor = colorAleatorio
        view.tintColor = colorAleatorio
        
  }
    
}

