//: Playground - Velocímetro
// Alfonso Ardila - Curso Programación Swift - 2016 - Evaluación


import UIKit

enum Velocidades : Int{
    case Apagado = 0
    case VelocidadBaja = 20
    case VelocidadMedia = 50
    case VelocidadAlta = 120
    
    init(velocidadInicial : Velocidades){
        self = velocidadInicial
    }
}

class Auto {
    
    var velocidad : Velocidades
   
    
    init() {
            velocidad = Velocidades ( velocidadInicial : .Apagado )
    }
    
        func cambioDeVelocidad() -> (actual : Int, velocidadEnCadena : String) {
    
        var mensaje = "INDETERMINADA"
        let actual = velocidad.rawValue
            switch velocidad {
            case .Apagado:
                velocidad = .VelocidadBaja
                mensaje = "Vehículo Apagado"
            case .VelocidadBaja:
                velocidad = .VelocidadMedia
                mensaje = "Vehículo avanza a baja velocidad"
            case .VelocidadMedia:
                velocidad = .VelocidadAlta
                mensaje = "Avanzando a velocidad media"
            case .VelocidadAlta:
                velocidad = .VelocidadMedia
                mensaje = "Transitando a alta velocidad"
            }
            return (actual, mensaje)
            
    }
}

let auto = Auto()

for i in 1...20 {
    let resultado = auto.cambioDeVelocidad()
    print("\(i). \(resultado.actual), \(resultado.velocidadEnCadena)")
}
